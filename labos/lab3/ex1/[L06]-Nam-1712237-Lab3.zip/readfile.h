#if !defined(READ_FILE_H)
#define READ_FILE_H

#include "linked_list.h"
#include <stdlib.h>
#include <stdio.h>

void readfile(Node** list);

#endif // READ_FILE_H
